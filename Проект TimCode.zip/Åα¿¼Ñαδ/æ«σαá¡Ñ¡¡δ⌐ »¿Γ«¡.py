import tkinter as tk
окно = tk.Tk()
окно.title('Кликер на основе примера')
окно.geometry("600x400")#Размеры по x y
окно.maxsize(800,800)
окно.minsize(100,100)
окно.configure(bg = "#000000")#можно set any цвет from списка цветов или HEX
a = 0

def кликер():
    global a
    a += 1
    print(f"Клик + {a}")

кнопка = tk.Button(окно, text = 'Нажми на кнопку', command = кликер, bg = "#FA8072", width = 30, height = 30, activebackground = "#FFC0CB" )
кнопка.pack(pady = 10)

# Остальной код виджетов и прочих методов
окно.mainloop()